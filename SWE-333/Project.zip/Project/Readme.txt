**********************************
LOGIN
**********************************
For Admin:
Email: 	  ashiqur35-2149@diu.edu.bd
Password: 1122

**********************************
For User:
Email: 	  ardipta82@gmail.com
Password: 1235

